class About {
  final String title;
  final List<String> paragraphs;

  About({
    required this.title,
    required this.paragraphs,
  });
}
